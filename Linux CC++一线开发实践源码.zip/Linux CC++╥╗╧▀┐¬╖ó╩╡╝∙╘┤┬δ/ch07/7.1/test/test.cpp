#include <stdio.h>

int main()
{
	printf("Content-Type: text/html\n\n");
	printf("Hello cgi!\n");
	return 0;
}
