#include <iostream>
using namespace std;
void f1(int age)
{
	cout << "this is libtest1.so: " << age << endl;
}
