#include <iostream>
using namespace std;
void f2(int age)
{
	cout << "this is libtest2.so: " << age << endl;
}
