#include  <stdio.h>
void f(int age)
{
	printf("age:%d\n", age);
}
