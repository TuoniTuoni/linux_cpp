extern void f(int age);
 

int main(int argc, char *argv[])
{
	f(66);
	return 0;
 
}