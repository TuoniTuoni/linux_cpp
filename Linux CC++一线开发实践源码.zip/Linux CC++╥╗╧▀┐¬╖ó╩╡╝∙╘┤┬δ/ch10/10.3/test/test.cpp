#include  <stdio.h>
#include <iostream>
using namespace std;
void f(int age)
{
	cout << "your age is " << age << endl;
	printf("age:%d\n", age);
}
