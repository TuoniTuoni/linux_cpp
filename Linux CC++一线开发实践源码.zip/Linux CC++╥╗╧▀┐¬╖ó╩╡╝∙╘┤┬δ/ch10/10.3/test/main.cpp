extern void f(int age);   //����Ҫʹ�õĺ���
#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
	f(66);
	cout << "HI" << endl;
	
	return 0;
}
