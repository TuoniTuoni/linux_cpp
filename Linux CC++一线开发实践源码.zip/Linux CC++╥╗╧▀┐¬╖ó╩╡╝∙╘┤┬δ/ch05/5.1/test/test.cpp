#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
	pid_t pid;
 
	cout <<"sizeof(pid_t)="<< sizeof(pid_t) << endl;	 
	return 0;
}