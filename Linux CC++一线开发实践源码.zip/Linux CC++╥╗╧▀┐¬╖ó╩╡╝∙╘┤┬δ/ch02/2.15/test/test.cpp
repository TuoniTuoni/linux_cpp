#include <stdio.h>
 
int main()
{
        bool b = false;
        int i;
        printf("hello, boy:%d\n",i); //iû�и�ֵ�Ϳ�ʼʹ��
        return 0;
}
