#include <stdio.h>
 
int main()
{
        printf("hello, boy \n" );  
        return 0;
}
