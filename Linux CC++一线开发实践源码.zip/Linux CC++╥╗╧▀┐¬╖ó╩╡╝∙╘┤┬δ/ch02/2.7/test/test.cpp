#include <stdio.h>

int main(int argc, char *argv[])
{
	char sz[] = "Hello, World!\n";	 
	printf("%s", sz);	
	fflush(stdout);  
	return 0;
}
