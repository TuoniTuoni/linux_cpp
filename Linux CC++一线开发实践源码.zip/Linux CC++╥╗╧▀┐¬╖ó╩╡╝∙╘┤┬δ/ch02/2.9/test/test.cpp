#include <stdio.h>
 
int main()
{
        bool b=false;
        printf("hello, boy \n" );  
        return 0;
}
