#include <iostream>
using namespace std;
int main()
{
        bool b = false;
        cout<< "hello, boy \n";  
        return 0;
}
