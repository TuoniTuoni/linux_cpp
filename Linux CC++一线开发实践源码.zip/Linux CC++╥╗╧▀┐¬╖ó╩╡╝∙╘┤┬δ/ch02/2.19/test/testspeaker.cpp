#include "speaker.h"
int main(int argc,char *argv[])
{
    speaker speak;  //定义对象speak
    speak.sayHello("world"); //调用成员函数sayHello
    return 0;
}

