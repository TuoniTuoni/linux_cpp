#include "speaker.h"
#include <iostream>
using namespace std;
void speaker::sayHello(const char *str)
{
    cout << "Hello " << str << "\n";
}

