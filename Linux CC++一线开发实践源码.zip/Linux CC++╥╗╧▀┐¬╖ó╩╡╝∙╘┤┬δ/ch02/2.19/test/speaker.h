
class speaker
{
    public:
        void sayHello(const char *);
};

