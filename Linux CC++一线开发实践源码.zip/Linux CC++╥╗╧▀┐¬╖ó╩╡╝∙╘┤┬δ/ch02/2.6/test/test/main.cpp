#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
	char sz[] = "Hello, World!";
	cout << sz << endl;
	return 0;
}
