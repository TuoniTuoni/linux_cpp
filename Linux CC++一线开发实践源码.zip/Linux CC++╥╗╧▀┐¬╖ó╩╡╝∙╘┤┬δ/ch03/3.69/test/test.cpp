 #include <iostream>
#include <string>
using namespace std;

int main ()
{
  string mystring;
  mystring = 
    "This is the initial string content";
  cout << mystring << endl;
  mystring = 
    "This is a different string content";
  cout << mystring << endl;
  return 0;
}