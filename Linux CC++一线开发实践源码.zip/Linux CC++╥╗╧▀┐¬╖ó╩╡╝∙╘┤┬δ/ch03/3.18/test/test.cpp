#include <iostream>
using namespace std;

void printmessage ()
{
  cout << "I'm a function!\n";
}

int main ()
{
  printmessage ();
  return 0;
}