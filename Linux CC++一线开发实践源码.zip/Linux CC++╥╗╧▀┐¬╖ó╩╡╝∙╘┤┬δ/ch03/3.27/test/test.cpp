#include <iostream>
using namespace std;
#include <string.h>
int main() {
	char szMyName[20];
	strcpy(szMyName, "J. Soulie");
	cout << szMyName << endl;
	return 0;
} 