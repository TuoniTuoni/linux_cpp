#include <iostream>

  // ANSI-C++ compliant hello world
#include <iostream>
    
int main() {
	std::cout << "Hello world in ANSI-C++\n";
	return 0;
}  